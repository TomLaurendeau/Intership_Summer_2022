g++ harris.c -fpermissive -o harris
